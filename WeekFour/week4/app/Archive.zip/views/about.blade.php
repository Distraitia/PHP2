@extends('layout.default')
@section('content')
   <h1>Welcome to my about page</h1>
@stop
