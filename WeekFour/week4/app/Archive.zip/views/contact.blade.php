@extends('layout.default')
@section('content')
   <h1>Welcome to my contact page</h1>
@stop
